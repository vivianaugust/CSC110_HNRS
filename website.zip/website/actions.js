function doSomething() {
    search = document.getElementById("searchText").value;
    document.getElementById("output").innerHTML = search
};

function checkEnter(event) {
    if (event.keyCode == 13) {
        search = document.getElementById("searchText").value;
        document.getElementById("output").innerHTML = search
    }
}